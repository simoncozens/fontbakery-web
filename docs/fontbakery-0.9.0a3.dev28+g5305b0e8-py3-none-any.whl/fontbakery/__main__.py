import fontbakery.cli

if __name__ == "__main__":
    fontbakery.cli.main()
